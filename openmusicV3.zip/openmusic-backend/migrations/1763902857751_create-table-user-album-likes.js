/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('user_album_likes', {
        id: {
            type: 'VARCHAR(50)',
            primaryKey: true,
        },
        user_id: {
            type: 'VARCHAR(50)',
            references: '"users"(id)',
            onDelete: 'CASCADE',
            notNull: true,
        },
        album_id: {
            type: 'VARCHAR(50)',
            references: '"albums"(id)',
            onDelete: 'CASCADE',
            notNull: true,
        },
    });

    pgm.addConstraint(
        'user_album_likes',
        'unique_user_album_likes',
        'UNIQUE(user_id, album_id)'
    );
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = (pgm) => {
    pgm.dropTable('user_album_likes');
};
