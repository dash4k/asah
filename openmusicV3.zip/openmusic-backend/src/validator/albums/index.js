const InvariantError = require('../../exceptions/InvariantError');
const { 
    AlbumPayloadSchema, 
    CoverHeadersSchema,
} = require('./schema');

const AlbumValidator = {
    validateAlbumPayload: (payload) => {
        const validationResult = AlbumPayloadSchema.validate(payload);
        if (validationResult.error) {
            throw new InvariantError(validationResult.error.message);
        }
    },
    validateCoverHeaders: (headers) => {
        const validationResult = CoverHeadersSchema.validate(headers);

        if (validationResult.error) {
            throw new InvariantError(validationResult.error.message);
        }
    },
};

module.exports = AlbumValidator;
