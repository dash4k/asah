const Joi = require('joi');

const DeletePlaylistSongPayloadSchema = Joi.object({
    songId: Joi.string().required(),
});

const PostPlaylistPayloadSchema = Joi.object({
    name: Joi.string().required(),
});

const PostPlaylistSongPayloadSchema = Joi.object({
    songId: Joi.string().required(),
});

module.exports = {
    DeletePlaylistSongPayloadSchema,
    PostPlaylistPayloadSchema,
    PostPlaylistSongPayloadSchema,
};
